"use client";

import { useEffect, useState } from "react";

export function MSWProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(process.env.NODE_ENV !== "development");

  useEffect(() => {
    if (process.env.NODE_ENV !== "development") return;

    async function init() {
      const { worker } = await import("@/mocks/browser");
      await worker.start({
        onUnhandledRequest: "bypass", // przepuszcza inne zapytania (np. statyki Next.js)
      });
      setReady(true);
    }

    init();
  }, []);

  if (!ready) return null;

  return <>{children}</>;
}